# Bot điểm danh sự kiện `!chiemdong`

Bot Discord (discord.py 2.x, Python 3.10+) tạo bảng điểm danh có nút `+1` / `-1`.
Dữ liệu lưu bằng SQLite nên bảng và nút vẫn hoạt động sau khi bot khởi động lại.

## Cấu trúc

```
chiemdong_bot/
├── main.py              # điểm khởi động
├── requirements.txt
├── .env.example         # tệp ẩn (bắt đầu bằng dấu chấm)
├── .gitignore           # tệp ẩn
└── chiemdong/
    ├── config.py        # đọc biến môi trường
    ├── models.py        # dataclass
    ├── database.py      # SQLite, thao tác nguyên tử, khóa theo bảng
    ├── embeds.py        # dựng embed
    ├── views.py         # nút +1/-1 (persistent) và modal lý do
    ├── cog.py           # lệnh !chiemdong
    └── client.py        # lớp Bot
```

> Tệp bắt đầu bằng dấu chấm (`.env.example`, `.gitignore`) bị ẩn mặc định trên macOS/Linux.
> macOS: nhấn `Cmd + Shift + .` trong Finder. Linux: `ls -A`. Windows: bật "Hidden items" trong Explorer.

## Thiết lập Discord

1. Tạo ứng dụng tại https://discord.com/developers/applications, vào tab **Bot** và lấy token.
2. Bật **Message Content Intent** (Bot > Privileged Gateway Intents). Thiếu bước này bot báo `PrivilegedIntentsRequired`.
3. Mời bot: OAuth2 > URL Generator, scope `bot`, quyền **View Channels**, **Send Messages**, **Embed Links**, **Read Message History**.

## Cài và chạy

```bash
cd chiemdong_bot
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env             # Windows: copy .env.example .env
# Mở .env và thay [DISCORD_TOKEN] bằng token thật

python main.py
```

Cơ sở dữ liệu tự tạo tại `data/chiemdong.sqlite3`.
Biến tùy chọn: `DATABASE_PATH`, `LOG_LEVEL` (xem `.env.example`).

## Kiểm thử thủ công

| # | Việc làm | Kết quả mong đợi |
|---|---|---|
| 1 | Gõ `!chiemdong` | Bảng số 0, hai nút `+1`, `-1`, "Lý do giảm gần nhất: Chưa có." |
| 2 | Bấm `+1` ba lần | Số thành 3 |
| 3 | Bấm `-1`, nhập lý do, gửi | Bảng về 2, hiện lý do, người giảm, thời điểm |
| 4 | Gửi modal với lý do toàn khoảng trắng | Báo lý do không được để trống, số không đổi |
| 5 | Giảm về 0 rồi bấm `-1` | Báo "đang là 0", không mở modal |
| 6 | Hai người cùng bấm `+1` | Số tăng đủ 2 lần |
| 7 | Tạo bảng thứ hai | Hai bảng đếm độc lập |
| 8 | Dừng bot, chạy lại, bấm nút trên bảng cũ | Nút vẫn hoạt động, dữ liệu giữ nguyên |
| 9 | Gõ lệnh trong tin nhắn riêng với bot | Báo chỉ dùng trong máy chủ |

## Kiểm tra dữ liệu và lịch sử

```bash
sqlite3 data/chiemdong.sqlite3 "SELECT message_id, channel_id, count, last_reason FROM boards;"
sqlite3 data/chiemdong.sqlite3 "SELECT id, message_id, user_id, reason, count_before, count_after, created_at FROM decrement_history ORDER BY id DESC LIMIT 10;"
```

## Lỗi thường gặp

- `PrivilegedIntentsRequired`: chưa bật Message Content Intent.
- Gõ lệnh mà bot im lặng: kiểm tra quyền View Channels / Send Messages và log "Đã đăng nhập".
- "Bot đang thiếu quyền…": cấp thêm quyền (thường là Embed Links).
- Nút báo "This interaction failed" sau khi khởi động lại: kiểm tra log có dòng "Đã đăng ký persistent view"; nếu từng đổi `custom_id` thì bảng cũ không còn khớp.
- Bảng báo "không tìm thấy dữ liệu": đã xóa hoặc đổi `DATABASE_PATH`; hãy tạo bảng mới.
- Cần log chi tiết: đặt `LOG_LEVEL=DEBUG` trong `.env`.
