"""Lệnh !chiemdong."""
from __future__ import annotations

import logging

import discord
from discord.ext import commands

from .database import BoardStore, StorageError
from .embeds import build_board_embed
from .models import Board
from .views import CounterView

logger = logging.getLogger(__name__)


class AttendanceCog(commands.Cog):
    def __init__(self, store: BoardStore) -> None:
        self.store = store

    @commands.command(name="chiemdong", help="Tạo một bảng điểm danh sự kiện mới (bắt đầu từ 0).")
    @commands.guild_only()
    @commands.bot_has_permissions(send_messages=True, embed_links=True)
    async def chiemdong(self, ctx: commands.Context) -> None:
        if ctx.guild is None:  # guild_only đã chặn; giữ để thu hẹp kiểu
            return

        draft = Board.draft(
            channel_id=ctx.channel.id, guild_id=ctx.guild.id, creator_id=ctx.author.id
        )
        # Mỗi message dùng một instance view riêng; view đăng ký ở setup_hook lo phần sau khi khởi động lại.
        message = await ctx.send(embed=build_board_embed(draft), view=CounterView(self.store))

        try:
            await self.store.create_board(
                message_id=message.id,
                channel_id=ctx.channel.id,
                guild_id=ctx.guild.id,
                creator_id=ctx.author.id,
            )
        except StorageError:
            logger.exception("Không lưu được bảng mới (message_id=%s)", message.id)
            await self._discard_message(message)
            await ctx.reply(
                "Không thể tạo bảng do lỗi lưu trữ dữ liệu. Vui lòng thử lại sau.",
                mention_author=False,
            )
            return

        logger.info(
            "Đã tạo bảng: message_id=%s channel_id=%s user_id=%s",
            message.id,
            ctx.channel.id,
            ctx.author.id,
        )

    @staticmethod
    async def _discard_message(message: discord.Message) -> None:
        """Xóa bảng không có dữ liệu để không còn nút bấm mồ côi."""
        try:
            await message.delete()
        except discord.HTTPException:
            logger.warning("Không xóa được message bảng lỗi %s", message.id, exc_info=True)
