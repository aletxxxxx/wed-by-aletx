"""Các cấu trúc dữ liệu thuần, không phụ thuộc Discord hay SQLite."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum


@dataclass(frozen=True, slots=True)
class Board:
    """Một bảng điểm danh (tương ứng một message Discord)."""

    message_id: int
    channel_id: int
    guild_id: int
    creator_id: int
    count: int
    created_at: datetime
    last_reason: str | None = None
    last_reason_user_id: int | None = None
    last_reason_at: datetime | None = None

    @classmethod
    def draft(cls, *, channel_id: int, guild_id: int, creator_id: int) -> Board:
        """Bảng tạm (message_id=0) chỉ dùng để dựng embed trước khi có ID message thật."""
        return cls(
            message_id=0,
            channel_id=channel_id,
            guild_id=guild_id,
            creator_id=creator_id,
            count=0,
            created_at=datetime.now(timezone.utc),
        )


class DecrementStatus(Enum):
    OK = "ok"
    NOT_FOUND = "not_found"
    AT_ZERO = "at_zero"


@dataclass(frozen=True, slots=True)
class DecrementResult:
    status: DecrementStatus
    board: Board | None
