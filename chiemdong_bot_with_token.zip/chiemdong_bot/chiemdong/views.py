"""View chứa nút +1 / -1 (persistent) và modal nhập lý do khi giảm."""
from __future__ import annotations

import logging

import discord

from .config import MAX_REASON_LENGTH
from .database import BoardStore, StorageError
from .embeds import build_board_embed
from .models import Board, DecrementStatus

logger = logging.getLogger(__name__)

INCREMENT_CUSTOM_ID = "chiemdong:increment"
DECREMENT_CUSTOM_ID = "chiemdong:decrement"
MODAL_TIMEOUT_SECONDS = 600

MSG_STORAGE_ERROR = "Có lỗi khi truy cập dữ liệu. Vui lòng thử lại sau."
MSG_UNEXPECTED_ERROR = "Đã xảy ra lỗi không mong muốn. Vui lòng thử lại."
MSG_NO_MESSAGE = "Không xác định được bảng điểm danh từ tương tác này."
MSG_BOARD_NOT_FOUND = (
    "Không tìm thấy dữ liệu của bảng này (có thể đã bị xóa khỏi cơ sở dữ liệu). "
    "Hãy tạo bảng mới bằng `!chiemdong`."
)
MSG_REFRESH_FAILED = (
    "Đã ghi nhận thao tác nhưng không cập nhật được bảng trên Discord. "
    "Bảng sẽ hiển thị đúng ở lần bấm tiếp theo."
)


async def send_ephemeral(interaction: discord.Interaction, content: str) -> None:
    """Gửi tin nhắn chỉ người bấm thấy, dù interaction đã được defer hay chưa."""
    try:
        if interaction.response.is_done():
            await interaction.followup.send(content, ephemeral=True)
        else:
            await interaction.response.send_message(content, ephemeral=True)
    except discord.HTTPException:
        logger.warning("Không gửi được phản hồi ephemeral cho người dùng", exc_info=True)


async def refresh_board_message(message: discord.Message, board: Board) -> bool:
    """Cập nhật embed của message bảng. Không truyền `view` nên các nút giữ nguyên."""
    try:
        await message.edit(embed=build_board_embed(board))
        return True
    except discord.NotFound:
        logger.warning("Message bảng %s không còn tồn tại trên Discord", message.id)
    except discord.HTTPException:
        logger.exception("Không sửa được message bảng %s", message.id)
    return False


class DecrementReasonModal(discord.ui.Modal, title="Lý do giảm điểm danh"):
    reason = discord.ui.TextInput(
        label="Lý do giảm",
        style=discord.TextStyle.paragraph,
        placeholder="Ví dụ: nhập nhầm, người tham gia đã rút lui...",
        required=True,
        max_length=MAX_REASON_LENGTH,
    )

    def __init__(self, store: BoardStore, message: discord.Message) -> None:
        # timeout giúp discord.py dọn modal khỏi bộ nhớ nếu người dùng đóng hộp thoại.
        super().__init__(timeout=MODAL_TIMEOUT_SECONDS)
        self.store = store
        self.message = message

    async def on_submit(self, interaction: discord.Interaction) -> None:
        reason = self.reason.value.strip()
        if not reason:
            await send_ephemeral(
                interaction, "Lý do không được để trống. Hãy bấm `-1` và nhập lại."
            )
            return
        if len(reason) > MAX_REASON_LENGTH:
            await send_ephemeral(
                interaction, f"Lý do tối đa {MAX_REASON_LENGTH} ký tự. Hãy bấm `-1` và nhập lại."
            )
            return

        # Xác nhận interaction ngay để không vượt hạn 3 giây khi chờ khóa/DB.
        await interaction.response.defer(ephemeral=True, thinking=True)

        message_id = self.message.id
        async with self.store.board_lock(message_id):
            try:
                result = await self.store.decrement(
                    message_id=message_id, user_id=interaction.user.id, reason=reason
                )
            except StorageError:
                logger.exception("Lỗi khi giảm bộ đếm (message_id=%s)", message_id)
                await send_ephemeral(interaction, MSG_STORAGE_ERROR)
                return

            if result.status is DecrementStatus.NOT_FOUND or result.board is None:
                await send_ephemeral(interaction, MSG_BOARD_NOT_FOUND)
                return

            refreshed = await refresh_board_message(self.message, result.board)

            if result.status is DecrementStatus.AT_ZERO:
                await send_ephemeral(
                    interaction, "Số điểm danh đã là 0 nên không thể giảm thêm."
                )
                return

        logger.info(
            "Giảm bộ đếm: message_id=%s user_id=%s count=%s",
            message_id,
            interaction.user.id,
            result.board.count,
        )
        text = f"Đã giảm xuống **{result.board.count}**. Lý do của bạn đã được lưu."
        if not refreshed:
            text += f"\n{MSG_REFRESH_FAILED}"
        await send_ephemeral(interaction, text)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        logger.error("Lỗi không mong muốn trong modal -1", exc_info=error)
        await send_ephemeral(interaction, MSG_UNEXPECTED_ERROR)


class CounterView(discord.ui.View):
    """View persistent: timeout=None và mọi nút đều có custom_id cố định.

    Cùng một view phục vụ mọi bảng; bảng được xác định bằng `interaction.message.id`.
    """

    def __init__(self, store: BoardStore) -> None:
        super().__init__(timeout=None)
        self.store = store

    @discord.ui.button(label="+1", style=discord.ButtonStyle.success, custom_id=INCREMENT_CUSTOM_ID)
    async def increment_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        message = interaction.message
        if message is None:
            await send_ephemeral(interaction, MSG_NO_MESSAGE)
            return

        await interaction.response.defer()

        async with self.store.board_lock(message.id):
            try:
                board = await self.store.increment(message.id)
            except StorageError:
                logger.exception("Lỗi khi tăng bộ đếm (message_id=%s)", message.id)
                await send_ephemeral(interaction, MSG_STORAGE_ERROR)
                return

            if board is None:
                await send_ephemeral(interaction, MSG_BOARD_NOT_FOUND)
                return

            refreshed = await refresh_board_message(message, board)

        if not refreshed:
            await send_ephemeral(interaction, MSG_REFRESH_FAILED)

    @discord.ui.button(label="-1", style=discord.ButtonStyle.danger, custom_id=DECREMENT_CUSTOM_ID)
    async def decrement_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        message = interaction.message
        if message is None:
            await send_ephemeral(interaction, MSG_NO_MESSAGE)
            return

        # Kiểm tra nhanh để khỏi bắt người dùng nhập lý do vô ích khi số đếm đã là 0.
        # Chốt chặn thật sự nằm ở câu UPDATE `count > 0` khi modal được gửi.
        try:
            board = await self.store.get_board(message.id)
        except StorageError:
            logger.exception("Lỗi khi đọc bảng (message_id=%s)", message.id)
            await send_ephemeral(interaction, MSG_STORAGE_ERROR)
            return

        if board is None:
            await send_ephemeral(interaction, MSG_BOARD_NOT_FOUND)
            return
        if board.count <= 0:
            await send_ephemeral(interaction, "Số điểm danh đang là 0 nên không thể giảm thêm.")
            return

        await interaction.response.send_modal(DecrementReasonModal(self.store, message))

    async def on_error(
        self, interaction: discord.Interaction, error: Exception, item: discord.ui.Item
    ) -> None:
        logger.error("Lỗi không mong muốn ở nút %s", item.custom_id, exc_info=error)
        await send_ephemeral(interaction, MSG_UNEXPECTED_ERROR)
