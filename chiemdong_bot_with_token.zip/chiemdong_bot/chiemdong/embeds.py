"""Dựng embed hiển thị bảng điểm danh."""
from __future__ import annotations

import discord

from .models import Board

EMBED_COLOR = discord.Color.blurple()


def _format_last_reason(board: Board) -> str:
    if not board.last_reason or board.last_reason_at is None:
        return "Chưa có."
    reason = discord.utils.escape_markdown(board.last_reason)
    when = discord.utils.format_dt(board.last_reason_at, style="R")
    by = f"<@{board.last_reason_user_id}>" if board.last_reason_user_id else "không rõ"
    return f"{reason}\n— {by}, {when}"


def build_board_embed(board: Board) -> discord.Embed:
    embed = discord.Embed(
        title="Bảng điểm danh sự kiện",
        description=f"Số điểm danh hiện tại\n# {board.count}",
        color=EMBED_COLOR,
    )
    embed.add_field(name="Tạo bởi", value=f"<@{board.creator_id}>", inline=False)
    embed.add_field(name="Lý do giảm gần nhất", value=_format_last_reason(board), inline=False)
    return embed
