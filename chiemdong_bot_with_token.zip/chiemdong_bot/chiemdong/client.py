"""Lớp Bot: khởi tạo intents, đăng ký persistent view và cog, xử lý lỗi lệnh."""
from __future__ import annotations

import logging

import discord
from discord.ext import commands

from .cog import AttendanceCog
from .config import COMMAND_PREFIX
from .database import BoardStore
from .views import CounterView

logger = logging.getLogger(__name__)


class ChiemDongBot(commands.Bot):
    def __init__(self, store: BoardStore) -> None:
        intents = discord.Intents.default()
        intents.message_content = True  # bắt buộc cho prefix command
        super().__init__(
            command_prefix=COMMAND_PREFIX,
            intents=intents,
            help_command=None,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        self.store = store

    async def setup_hook(self) -> None:
        await self.store.connect()
        # Đăng ký lại persistent view mỗi lần khởi động: nút của mọi bảng cũ hoạt động trở lại.
        self.add_view(CounterView(self.store))
        await self.add_cog(AttendanceCog(self.store))
        logger.info(
            "Đã đăng ký persistent view. Số bảng trong cơ sở dữ liệu: %d",
            await self.store.count_boards(),
        )

    async def on_ready(self) -> None:
        logger.info("Đã đăng nhập: %s (ID %s)", self.user, self.user.id if self.user else "?")

    async def close(self) -> None:
        await self.store.close()
        await super().close()

    async def on_command_error(
        self, ctx: commands.Context, error: commands.CommandError
    ) -> None:
        if isinstance(error, commands.CommandNotFound):
            return

        if isinstance(error, commands.NoPrivateMessage):
            message = "Lệnh này chỉ dùng được trong máy chủ."
        elif isinstance(error, commands.BotMissingPermissions):
            missing = ", ".join(error.missing_permissions)
            message = f"Bot đang thiếu quyền trong kênh này: {missing}."
        elif isinstance(error, commands.CheckFailure):
            message = "Bạn không thể dùng lệnh này ở đây."
        else:
            logger.error("Lỗi khi chạy lệnh %s", ctx.command, exc_info=error)
            message = "Đã xảy ra lỗi khi chạy lệnh. Vui lòng thử lại sau."

        try:
            await ctx.reply(message, mention_author=False)
        except discord.HTTPException:
            logger.warning("Không gửi được thông báo lỗi lệnh vào kênh", exc_info=True)
