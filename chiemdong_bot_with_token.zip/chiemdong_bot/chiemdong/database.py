"""Lưu trữ SQLite bằng aiosqlite.

Quyết định thiết kế:
- Một kết nối duy nhất, mọi thao tác chạy trong `_session()` được bảo vệ bởi một asyncio.Lock
  để các transaction không đan xen nhau trên cùng kết nối.
- Tăng/giảm dùng một câu UPDATE nguyên tử; giảm có điều kiện `count > 0` nên không bao giờ âm.
- `board_lock()` cấp khóa theo từng bảng để tầng giao diện có thể xếp thứ tự
  "cập nhật DB -> sửa message" cho các lần bấm đồng thời.
"""
from __future__ import annotations

import asyncio
import logging
import sqlite3
import weakref
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncIterator

import aiosqlite

from .models import Board, DecrementResult, DecrementStatus

logger = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS boards (
    message_id          INTEGER PRIMARY KEY,
    channel_id          INTEGER NOT NULL,
    guild_id            INTEGER NOT NULL,
    creator_id          INTEGER NOT NULL,
    count               INTEGER NOT NULL DEFAULT 0 CHECK (count >= 0),
    last_reason         TEXT,
    last_reason_user_id INTEGER,
    last_reason_at      TEXT,
    created_at          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS decrement_history (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id    INTEGER NOT NULL REFERENCES boards (message_id) ON DELETE CASCADE,
    channel_id    INTEGER NOT NULL,
    user_id       INTEGER NOT NULL,
    reason        TEXT NOT NULL,
    count_before  INTEGER NOT NULL,
    count_after   INTEGER NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_decrement_history_message
    ON decrement_history (message_id, id);
"""


class StorageError(RuntimeError):
    """Lỗi truy cập cơ sở dữ liệu (đã được bọc từ sqlite3.Error)."""


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _row_to_board(row: sqlite3.Row) -> Board:
    last_at = row["last_reason_at"]
    return Board(
        message_id=row["message_id"],
        channel_id=row["channel_id"],
        guild_id=row["guild_id"],
        creator_id=row["creator_id"],
        count=row["count"],
        created_at=datetime.fromisoformat(row["created_at"]),
        last_reason=row["last_reason"],
        last_reason_user_id=row["last_reason_user_id"],
        last_reason_at=datetime.fromisoformat(last_at) if last_at else None,
    )


class BoardStore:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._db: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()
        # WeakValueDictionary: khóa tự được dọn khi không còn ai dùng, không phình bộ nhớ.
        self._board_locks: weakref.WeakValueDictionary[int, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )

    # ------------------------------------------------------------------ vòng đời

    async def connect(self) -> None:
        if self._db is not None:
            return
        self._path.parent.mkdir(parents=True, exist_ok=True)
        db: aiosqlite.Connection | None = None
        try:
            db = await aiosqlite.connect(self._path)
            db.row_factory = sqlite3.Row
            await db.execute("PRAGMA journal_mode = WAL")
            await db.execute("PRAGMA foreign_keys = ON")
            await db.executescript(SCHEMA)
            await db.commit()
        except sqlite3.Error as exc:
            if db is not None:
                await db.close()
            raise StorageError(f"Không thể mở cơ sở dữ liệu {self._path}: {exc}") from exc
        self._db = db
        logger.info("Đã kết nối SQLite: %s", self._path)

    async def close(self) -> None:
        if self._db is not None:
            await self._db.close()
            self._db = None
            logger.info("Đã đóng kết nối SQLite")

    # ------------------------------------------------------------------ tiện ích nội bộ

    def board_lock(self, message_id: int) -> asyncio.Lock:
        """Khóa theo từng bảng, dùng để xếp thứ tự các lần bấm đồng thời."""
        lock = self._board_locks.get(message_id)
        if lock is None:
            lock = asyncio.Lock()
            self._board_locks[message_id] = lock
        return lock

    @asynccontextmanager
    async def _session(self) -> AsyncIterator[aiosqlite.Connection]:
        """Một transaction: commit khi thành công, rollback khi lỗi."""
        if self._db is None:
            raise StorageError("Cơ sở dữ liệu chưa được kết nối")
        db = self._db
        async with self._lock:
            try:
                yield db
                await db.commit()
            except sqlite3.Error as exc:
                await db.rollback()
                raise StorageError(f"Lỗi SQLite: {exc}") from exc
            except BaseException:
                await db.rollback()
                raise

    @staticmethod
    async def _fetch_board(db: aiosqlite.Connection, message_id: int) -> Board | None:
        async with db.execute(
            "SELECT * FROM boards WHERE message_id = ?", (message_id,)
        ) as cursor:
            row = await cursor.fetchone()
        return _row_to_board(row) if row is not None else None

    # ------------------------------------------------------------------ thao tác công khai

    async def count_boards(self) -> int:
        async with self._session() as db:
            async with db.execute("SELECT COUNT(*) AS n FROM boards") as cursor:
                row = await cursor.fetchone()
        return int(row["n"]) if row is not None else 0

    async def get_board(self, message_id: int) -> Board | None:
        async with self._session() as db:
            return await self._fetch_board(db, message_id)

    async def create_board(
        self, *, message_id: int, channel_id: int, guild_id: int, creator_id: int
    ) -> Board:
        async with self._session() as db:
            await db.execute(
                "INSERT INTO boards (message_id, channel_id, guild_id, creator_id, count, created_at) "
                "VALUES (?, ?, ?, ?, 0, ?)",
                (message_id, channel_id, guild_id, creator_id, _utc_now_iso()),
            )
            board = await self._fetch_board(db, message_id)
        if board is None:  # không thể xảy ra sau INSERT thành công, giữ để an toàn
            raise StorageError("Không đọc lại được bảng vừa tạo")
        return board

    async def increment(self, message_id: int) -> Board | None:
        """Tăng 1. Trả về None nếu bảng không tồn tại."""
        async with self._session() as db:
            async with db.execute(
                "UPDATE boards SET count = count + 1 WHERE message_id = ?", (message_id,)
            ) as cursor:
                updated = cursor.rowcount
            if updated == 0:
                return None
            return await self._fetch_board(db, message_id)

    async def decrement(
        self, *, message_id: int, user_id: int, reason: str
    ) -> DecrementResult:
        """Giảm 1 kèm lý do và ghi lịch sử, trong cùng một transaction.

        Điều kiện `count > 0` nằm ngay trong câu UPDATE nên số đếm không bao giờ âm,
        kể cả khi có nhiều yêu cầu đồng thời.
        """
        now = _utc_now_iso()
        async with self._session() as db:
            async with db.execute(
                "UPDATE boards "
                "SET count = count - 1, last_reason = ?, last_reason_user_id = ?, last_reason_at = ? "
                "WHERE message_id = ? AND count > 0",
                (reason, user_id, now, message_id),
            ) as cursor:
                updated = cursor.rowcount

            if updated == 0:
                board = await self._fetch_board(db, message_id)
                status = DecrementStatus.NOT_FOUND if board is None else DecrementStatus.AT_ZERO
                return DecrementResult(status=status, board=board)

            board = await self._fetch_board(db, message_id)
            if board is None:  # không thể xảy ra sau UPDATE thành công
                raise StorageError("Không đọc lại được bảng sau khi giảm")
            await db.execute(
                "INSERT INTO decrement_history "
                "(message_id, channel_id, user_id, reason, count_before, count_after, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (message_id, board.channel_id, user_id, reason, board.count + 1, board.count, now),
            )
            return DecrementResult(status=DecrementStatus.OK, board=board)
