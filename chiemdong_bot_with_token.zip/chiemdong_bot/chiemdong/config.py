"""Cấu hình và hằng số dùng chung."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

COMMAND_PREFIX = "!"
MAX_REASON_LENGTH = 200
DEFAULT_DATABASE_PATH = "data/chiemdong.sqlite3"
TOKEN_PLACEHOLDER = "[DISCORD_TOKEN]"

_VALID_LOG_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}


class ConfigError(RuntimeError):
    """Cấu hình thiếu hoặc không hợp lệ."""


@dataclass(frozen=True, slots=True)
class Settings:
    token: str
    database_path: Path
    log_level: str


def load_settings() -> Settings:
    """Đọc cấu hình từ biến môi trường (và tệp .env nếu có)."""
    load_dotenv()

    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token or token == TOKEN_PLACEHOLDER:
        raise ConfigError(
            "Thiếu biến môi trường DISCORD_TOKEN. Sao chép .env.example thành .env "
            "rồi điền token bot thật vào."
        )

    log_level = os.getenv("LOG_LEVEL", "INFO").strip().upper()
    if log_level not in _VALID_LOG_LEVELS:
        log_level = "INFO"

    database_path = Path(os.getenv("DATABASE_PATH", DEFAULT_DATABASE_PATH).strip())

    return Settings(token=token, database_path=database_path, log_level=log_level)
