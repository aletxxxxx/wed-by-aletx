"""Điểm khởi động của bot điểm danh sự kiện."""
from __future__ import annotations

import logging
import sys

import discord

from chiemdong.client import ChiemDongBot
from chiemdong.config import ConfigError, load_settings
from chiemdong.database import BoardStore

logger = logging.getLogger("chiemdong")


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def main() -> int:
    configure_logging("INFO")

    try:
        settings = load_settings()
    except ConfigError as exc:
        logger.error("%s", exc)
        return 1

    # Áp dụng LOG_LEVEL người dùng chọn (nếu có).
    logging.getLogger().setLevel(settings.log_level)

    store = BoardStore(settings.database_path)
    bot = ChiemDongBot(store)

    try:
        # log_handler=None: dùng cấu hình logging ở trên thay vì handler mặc định của discord.py.
        bot.run(settings.token, log_handler=None)
    except discord.LoginFailure:
        logger.error("Token không hợp lệ. Kiểm tra lại DISCORD_TOKEN trong .env.")
        return 1
    except discord.PrivilegedIntentsRequired:
        logger.error(
            "Chưa bật Message Content Intent. Vào Discord Developer Portal > Bot > "
            "Privileged Gateway Intents và bật 'Message Content Intent'."
        )
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
