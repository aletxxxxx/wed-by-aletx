"""Kiểm tra nhanh bot Discord: token có đăng nhập được không, bot đang ở những máy chủ nào.

Cách dùng (đặt cạnh tệp .env, trong thư mục chiemdong_bot, đã bật .venv):
    python check_bot.py                 # chỉ kiểm tra đăng nhập
    python check_bot.py [CHANNEL_ID]    # đăng nhập và gửi 1 tin nhắn thử vào kênh đó
"""
from __future__ import annotations

import os
import sys

import discord
from dotenv import load_dotenv


class CheckClient(discord.Client):
    def __init__(self, channel_id: int | None) -> None:
        intents = discord.Intents.default()
        intents.message_content = True  # giống bot thật, để phát hiện intent chưa bật
        super().__init__(intents=intents)
        self.channel_id = channel_id
        self.ok = False

    async def on_ready(self) -> None:
        print(f"[OK] Đăng nhập thành công: {self.user} (ID {self.user.id if self.user else '?'})")
        print(f"[OK] Bot đang ở {len(self.guilds)} máy chủ:")
        for guild in self.guilds:
            print(f"     - {guild.name} (ID {guild.id})")
        if not self.guilds:
            print("[!] Bot chưa ở máy chủ nào. Hãy mời bot bằng OAuth2 > URL Generator.")

        self.ok = True
        if self.channel_id is not None:
            await self._send_test_message()
        await self.close()

    async def _send_test_message(self) -> None:
        try:
            channel = self.get_channel(self.channel_id) or await self.fetch_channel(self.channel_id)
            await channel.send("Bot đang hoạt động bình thường.")  # type: ignore[union-attr]
            print(f"[OK] Đã gửi tin nhắn thử vào kênh {self.channel_id}")
        except discord.Forbidden:
            self.ok = False
            print("[LỖI] Bot không có quyền xem/gửi tin nhắn trong kênh này.")
        except discord.NotFound:
            self.ok = False
            print("[LỖI] Không tìm thấy kênh. Kiểm tra lại CHANNEL_ID và bot có ở máy chủ đó không.")
        except discord.HTTPException as exc:
            self.ok = False
            print(f"[LỖI] Gửi tin nhắn thất bại: {exc}")


def main() -> int:
    load_dotenv()
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token or token == "[DISCORD_TOKEN]":
        print("[LỖI] Chưa có DISCORD_TOKEN trong .env.")
        return 1

    channel_id: int | None = None
    if len(sys.argv) > 1:
        try:
            channel_id = int(sys.argv[1])
        except ValueError:
            print("[LỖI] CHANNEL_ID phải là số.")
            return 1

    client = CheckClient(channel_id)
    try:
        client.run(token, log_handler=None)
    except discord.LoginFailure:
        print("[LỖI] Token không hợp lệ. Vào Developer Portal > Bot > Reset Token rồi dán token mới vào .env.")
        print("      Token thật có dạng 3 đoạn nối bằng dấu chấm, không phải chuỗi 64 ký tự hex.")
        return 1
    except discord.PrivilegedIntentsRequired:
        print("[LỖI] Chưa bật Message Content Intent (Developer Portal > Bot > Privileged Gateway Intents).")
        return 1
    except discord.HTTPException as exc:
        print(f"[LỖI] Không kết nối được tới Discord: {exc}")
        return 1

    return 0 if client.ok else 1


if __name__ == "__main__":
    sys.exit(main())
